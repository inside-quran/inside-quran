export * from './quranHelpers';
